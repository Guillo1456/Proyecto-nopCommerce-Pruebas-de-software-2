describe('template spec', () => {
    it('Poner reseña', () => {
    cy.visit('https://demo.nopcommerce.com/')
    cy.get('a.ico-login').click();
    cy.get('[name="Email"]').click();
    cy.get('[name="Email"]').type('nosee@gmail.com');
    cy.get('[name="Password"]').click();
    cy.get('[name="Password"]').type('david2007');
    cy.get('#main button.login-button').click();
    cy.get('#main img[alt="Picture of HTC smartphone"]').click();
    cy.get('#product-details-form a[href="#addreview"]').click();
    cy.get('[name="AddProductReview.Title"]').click();
    cy.get('[name="AddProductReview.Title"]').type('prueba');
    cy.get('[name="AddProductReview.ReviewText"]').click();
    cy.get('[name="AddProductReview.ReviewText"]').type('nose jsjs');
    cy.get('#addproductrating_3').check();
    cy.get('[name="add-review"]').click();
    });
});
