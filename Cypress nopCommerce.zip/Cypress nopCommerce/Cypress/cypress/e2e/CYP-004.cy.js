describe('template spec', () => {
    it('Categoria', () => {
        cy.visit('https://demo.nopcommerce.com/')
        cy.get('div.menu-toggle').click();
        cy.get('ul.mobile a[href="/computers"]').click();
    })
})