describe('template spec', () => {
    it('Cambiar contraseña', () => {
        cy.visit('https://demo.nopcommerce.com/')
        cy.get('a.ico-login').click();
        cy.get('[name="Email"]').click();
        cy.get('[name="Email"]').type('nosee@gmail.com');
        cy.get('[name="Password"]').click();
        cy.get('[name="Password"]').type('david2007');
        cy.get('#main button.login-button').click();
        cy.get('a.ico-account').click();
        cy.get('#main div.block strong').click();
        cy.get('#main a[href="/customer/changepassword"]').click();
        cy.get('[name="OldPassword"]').click();
        cy.get('[name="OldPassword"]').type('david2007');
        cy.get('[name="NewPassword"]').click();
        cy.get('[name="NewPassword"]').type('guiller2007');
        cy.get('[name="ConfirmNewPassword"]').click();
        cy.get('[name="ConfirmNewPassword"]').type('guiller2007');
        cy.get('#main button.change-password-button').click();
    })
})