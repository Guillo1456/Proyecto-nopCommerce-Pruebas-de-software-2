describe('template spec', () => {
    it('Iniciar', () => {
        cy.visit('https://demo.nopcommerce.com/')
        cy.get('a.ico-login').click();
        cy.get('[name="Email"]').click();
        cy.get('[name="Email"]').type('nosee@gmail.com');
        cy.get('[name="Password"]').click();
        cy.get('[name="Password"]').type('david2007');
        cy.get('#main button.login-button').click();
    })
})