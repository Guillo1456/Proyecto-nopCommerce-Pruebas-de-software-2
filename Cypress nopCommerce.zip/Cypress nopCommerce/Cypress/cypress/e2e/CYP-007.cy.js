describe('template spec', () => {
    it('Especificaciones', () => {
        cy.visit('https://demo.nopcommerce.com/')
        cy.get('div.menu-toggle').click();
        cy.get('ul.mobile a[href="/computers"]').click();
        cy.get('#main img[alt="Picture for category Desktops"]').click();
        cy.get('#main img[alt="Picture of Build your own computer"]').click();
        cy.get('[name="product_attribute_1"]').select('1');
        cy.get('[name="product_attribute_2"]').select('5');
        cy.get('#product_attribute_3_7').check();
        cy.get('#product_attribute_5_11').check();
        cy.get('#product_attribute_5_12').check();
    })
})