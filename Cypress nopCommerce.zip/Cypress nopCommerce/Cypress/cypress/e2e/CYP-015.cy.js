describe('template spec', () => {
    it('Añadir lista de deseos', () => {
    cy.visit('https://demo.nopcommerce.com/')
    cy.get('#main img[alt="Picture of HTC smartphone"]').click();
    cy.get('#add-to-wishlist-button-18').click();
    });
});