describe('template spec', () => {
    it('Buscar', () => {
        cy.visit('https://demo.nopcommerce.com/')
        cy.get('[name="q"]').click();
        cy.get('[name="q"]').type('apple');
        cy.get('#small-search-box-form button.search-box-button').click();
    })
})