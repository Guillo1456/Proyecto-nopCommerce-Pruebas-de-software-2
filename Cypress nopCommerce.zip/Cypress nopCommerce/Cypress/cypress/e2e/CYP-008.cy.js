describe('template spec', () => {
    it('Añadir al carrito', () => {
        cy.visit('https://demo.nopcommerce.com/')
        cy.get('#main img[alt="Picture of HTC smartphone"]').click();
        cy.get('#add-to-cart-button-18').click();
        cy.get('#topcartlink span.cart-label').click();
    })
})