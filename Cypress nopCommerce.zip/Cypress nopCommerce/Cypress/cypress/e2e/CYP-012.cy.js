describe('template spec', () => {
    it('Cambiar contraseña', () => {
        cy.visit('https://demo.nopcommerce.com/')
        cy.get('a.ico-login').click();
        cy.get('[name="Email"]').click();
        cy.get('[name="Email"]').type('nose@gmail.com');
        cy.get('[name="Password"]').click();
        cy.get('[name="Password"]').type('david2007');
        cy.get('#main button.login-button').click();
        cy.get('a.ico-account').click();
        cy.get('[name="FirstName"]').click();
        cy.get('[name="FirstName"]').clear();
        cy.get('[name="FirstName"]').type('David');
        cy.get('[name="LastName"]').click();
        cy.get('[name="LastName"]').type('s');
        cy.get('[name="save-info-button"]').click();
    })
})