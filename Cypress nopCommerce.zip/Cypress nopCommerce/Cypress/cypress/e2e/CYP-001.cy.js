describe('template spec', () => {
  it('Registro', () => {
    cy.visit('https://demo.nopcommerce.com/')
    cy.get('a.ico-register').click(); // hacer clic en el boton de registar 
    cy.get('#gender-male').check(); // Escoge en el genero en este caso masculino
    cy.get('[name="FirstName"]').click(); // hace click en el campo de nombre 
    cy.get('[name="FirstName"]').type('Davidxd'); // ingresa Davidxd
    cy.get('[name="LastName"]').click(); // hace click en el campo de apellido
    cy.get('[name="LastName"]').type('Riveros'); // ingresa Riveros
    cy.get('[name="Email"]').click(); // hace click en el campo de correo
    cy.get('[name="Email"]').type('nosee@gmail.com'); // ingresa nosee@gmail.com
    cy.get('[name="Company"]').click(); // hace click en el campo de compania
    cy.get('[name="Company"]').type('Ucompensar'); // ingresa ucompensar
    cy.get('[name="Password"]').click(); // hace click en el campo de contraseña
    cy.get('[name="Password"]').type('david2007'); // ingresa david2007
    cy.get('[name="ConfirmPassword"]').click(); // hace click en el campo de confirmar contraseña
    cy.get('[name="ConfirmPassword"]').type('david2007'); // ingresa david2007
    cy.get('[name="register-button"]').click(); // hace click en registrar
  })
})