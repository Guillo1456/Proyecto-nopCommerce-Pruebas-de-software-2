describe('template spec', () => {
    it('Comprar', () => {
    cy.visit('https://demo.nopcommerce.com/')
    cy.get('#main img[alt="Picture of HTC smartphone"]').click();
    cy.get('#add-to-cart-button-18').click();
    cy.get('#topcartlink span.cart-label').click();
    cy.get('[name="termsofservice"]').check();
    cy.get('[name="checkout"]').click();
    cy.get('[name="Email"]').click();
    cy.get('[name="Email"]').type('nosee');
    cy.get('[name="Email"]').type('@gmail.com');
    cy.get('[name="Password"]').click();
    cy.get('[name="Password"]').type('david2007');
    cy.get('#main button.login-button').click();
    cy.get('[name="termsofservice"]').check();
    cy.get('[name="checkout"]').click();
    cy.get('[name="BillingNewAddress.City"]').click();
    cy.get('[name="BillingNewAddress.City"]').type('bogota');
    cy.get('[name="BillingNewAddress.Address1"]').click();
    cy.get('[name="BillingNewAddress.Address1"]').type('calle 17');
    cy.get('[name="BillingNewAddress.ZipPostalCode"]').click();
    cy.get('[name="BillingNewAddress.ZipPostalCode"]').type('1104{enter}');
    cy.get('[name="BillingNewAddress.PhoneNumber"]').click();
    cy.get('[name="BillingNewAddress.PhoneNumber"]').type('5254454');
    cy.get('#billing-buttons-container [name="save"]').click();
    });
});