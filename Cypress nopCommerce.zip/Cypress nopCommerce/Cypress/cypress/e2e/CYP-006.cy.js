describe('template spec', () => {
    it('Filtro', () => {
        cy.visit('https://demo.nopcommerce.com/')
        cy.get('div.menu-toggle').click();
        cy.get('ul.mobile a[href="/computers"]').click();
        cy.get('#main img[alt="Picture for category Desktops"]').click();
        cy.get('#price-range-slider').click();
    })
})