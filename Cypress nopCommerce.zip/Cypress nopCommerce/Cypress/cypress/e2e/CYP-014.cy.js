describe('template spec', () => {
    it('Suscribirse', () => {
    cy.visit('https://demo.nopcommerce.com/')
    cy.get('[name="NewsletterEmail"]').click();
    cy.get('[name="NewsletterEmail"]').type('nosee@gmail.com');
    cy.get('#newsletter-subscribe-button').click();
    });
});